================================
Installation Instructions
================================

https://www.SourceForge.net/projects/cerberuscms/Documentation
https://www.GitHub.com/TinkeSoftware/CerberusCMS_Documentation

================================
Cerberus on Source Forge
================================

https://www.SourceForge.net/projects/cerberuscms/

================================
Cerberus on Source Forge ( Demo )
================================

http://CerberusCMS.SourceForge.net

================================
Cerberus on Git Hub
================================

https://www.GitHub.com/TinkeSoftware/CerberusCMS

================================
Cerberus on Bit Bucket
================================

https://www.BitBucket.org/TinkeSoftware/CerberusCMS
